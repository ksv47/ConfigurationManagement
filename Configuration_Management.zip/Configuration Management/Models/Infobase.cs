using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Configuration_Management.Models;

/// <summary>
/// Представляет информационную базу (аналог информационной базы 1С).
/// </summary>
public class Infobase : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    private bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
            return false;
        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }
    /// <summary>
    /// Идентификатор базы 1С (GUID из файла ibases.v8i, ключ ID).
    /// Используется для точной очистки кеша 1С.
    /// </summary>
    public string Id { get; set; } = string.Empty;

    /// <summary>Наименование информационной базы.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Группа, к которой относится база.</summary>
    public string Group { get; set; } = string.Empty;

    /// <summary>
    /// Порядок отображения базы внутри группы (меньше — выше в списке).
    /// Используется при перетаскивании между базами.
    /// </summary>
    public int SortOrder { get; set; }

    private bool _isFavorite;

    /// <summary>Признак избранной базы.</summary>
    public bool IsFavorite
    {
        get => _isFavorite;
        set => SetProperty(ref _isFavorite, value);
    }

    private int _favoriteHotkeyNumber;

    /// <summary>
    /// Номер горячей клавиши избранного (1–9 → Alt+N), 0 — не назначен.
    /// Отображается рядом со звездой в списке.
    /// </summary>
    public int FavoriteHotkeyNumber
    {
        get => _favoriteHotkeyNumber;
        set
        {
            if (SetProperty(ref _favoriteHotkeyNumber, value))
                OnPropertyChanged(nameof(FavoriteHotkeyDisplay));
        }
    }

    /// <summary>Текст номера для UI («1»…«9» или пусто).</summary>
    public string FavoriteHotkeyDisplay =>
        _favoriteHotkeyNumber >= 1 && _favoriteHotkeyNumber <= 9
            ? _favoriteHotkeyNumber.ToString()
            : string.Empty;

    private bool _isPinned;

    /// <summary>Признак закреплённой базы (отображается вверху списка без группы).</summary>
    public bool IsPinned
    {
        get => _isPinned;
        set => SetProperty(ref _isPinned, value);
    }

    private bool _isSelected;

    /// <summary>Признак выбранной базы в дереве (для синхронизации с TreeViewItem.IsSelected).</summary>
    public bool IsSelected
    {
        get => _isSelected;
        set => SetProperty(ref _isSelected, value);
    }

    private DateTime? _lastLaunchDate;

    /// <summary>Дата и время последнего запуска базы.</summary>
    public DateTime? LastLaunchDate
    {
        get => _lastLaunchDate;
        set
        {
            if (SetProperty(ref _lastLaunchDate, value))
                OnPropertyChanged(nameof(LastLaunchDisplay));
        }
    }

    private ConnectionSettings _connection = new();

    /// <summary>
    /// Настройки подключения к базе. Никогда не равен null:
    /// при десериализации (в том числе, когда в JSON свойство задано как null)
    /// значение гарантированно подменяется пустыми настройками, чтобы вычисляемые
    /// свойства (<see cref="ConnectionStringDisplay"/>, <see cref="ServerDatabaseDisplay"/>)
    /// не вызывали NullReferenceException при выборе базы.
    /// </summary>
    public ConnectionSettings Connection
    {
        get => _connection;
        set => _connection = value ?? new ConnectionSettings();
    }

    private RepositorySettings _repository = new();

    /// <summary>
    /// Настройки подключения к хранилищу конфигурации (адрес, имя хранилища,
    /// логин и пароль). Используются при работе в Конфигураторе для входа «под собой».
    /// Никогда не равен null: при десериализации подменяется пустыми настройками.
    /// </summary>
    public RepositorySettings Repository
    {
        get => _repository;
        set => _repository = value ?? new RepositorySettings();
    }

    /// <summary>
    /// Настройки авторизации для запуска «1С:Предприятие» (отдельно от Конфигуратора).
    /// Если значение равно null — Предприятие использует авторизацию информационной базы
    /// (<see cref="Connection"/>), что обеспечивает обратную совместимость.
    /// При задании отдельной авторизации она применяется при запуске «1С:Предприятие».
    /// </summary>
    public InfobaseAuthSettings? EnterpriseAuth { get; set; }

    /// <summary>
    /// Настройки авторизации для запуска Конфигуратора (отдельно от «1С:Предприятие»).
    /// Если значение равно null — Конфигуратор использует авторизацию информационной базы
    /// (<see cref="Connection"/>), что обеспечивает обратную совместимость.
    /// При задании отдельной авторизации она применяется при запуске Конфигуратора.
    /// </summary>
    public InfobaseAuthSettings? ConfiguratorAuth { get; set; }

    /// <summary>Версия платформы 1С.</summary>
    private string _platformVersion = string.Empty;
    /// <summary>Версия платформы 1С (например 8.3.27.1644).</summary>
    public string PlatformVersion
    {
        get => _platformVersion;
        set => SetProperty(ref _platformVersion, value ?? string.Empty);
    }

    private string _configurationName = string.Empty;
    private string _configurationVersion = string.Empty;

    /// <summary>Наименование конфигурации 1С (например «Бухгалтерия предприятия»).</summary>
    public string ConfigurationName
    {
        get => _configurationName;
        set
        {
            if (SetProperty(ref _configurationName, value ?? string.Empty))
                OnPropertyChanged(nameof(ConfigurationDisplay));
        }
    }

    /// <summary>Версия конфигурации 1С (например «3.0.142.32»).</summary>
    public string ConfigurationVersion
    {
        get => _configurationVersion;
        set
        {
            if (SetProperty(ref _configurationVersion, value ?? string.Empty))
                OnPropertyChanged(nameof(ConfigurationDisplay));
        }
    }

    /// <summary>Отображение: «Название (версия)» или одно из полей.</summary>
    public string ConfigurationDisplay
    {
        get
        {
            var n = (_configurationName ?? string.Empty).Trim();
            var v = (_configurationVersion ?? string.Empty).Trim();
            if (n.Length == 0 && v.Length == 0) return string.Empty;
            if (n.Length == 0) return v;
            if (v.Length == 0) return n;
            return $"{n} ({v})";
        }
    }

    /// <summary>Режим запуска (Автоматический, Тонкий клиент, Толстый клиент, Веб-клиент).</summary>
    private string _launchMode = "Автоматический";

    /// <summary>Режим запуска (Автоматический, Тонкий клиент, Толстый клиент, Веб-клиент).</summary>
    public string LaunchMode
    {
        get => _launchMode;
        set
        {
            if (SetProperty(ref _launchMode, value ?? "Автоматический"))
                OnPropertyChanged(nameof(ParsedLaunchMode));
        }
    }

    /// <summary>Дополнительные параметры запуска платформы 1С (например, /UC, /DisableStartupMessages и др.).</summary>
    public string LaunchParameters { get; set; } = string.Empty;

    /// <summary>Разрядность платформы при запуске базы («32» или «64» бита).</summary>
    public string Architecture { get; set; } = "32-priority";

    /// <summary>Человекочитаемая разрядность для UI (как в лаунчере 1С).</summary>
    public string ArchitectureDisplay => (Architecture ?? string.Empty).Trim().ToLowerInvariant() switch
    {
        "64" or "x64" => "64 (x86-64)",
        "32" or "x86" => "32 (x86)",
        "64-priority" => "Приоритет 64",
        "32-priority" => "Приоритет 32",
        _ => string.IsNullOrWhiteSpace(Architecture) ? "Приоритет 32" : Architecture
    };

    /// <summary>Тип клиента (тонкий или толстый).</summary>
    public string ClientType { get; set; } = "Тонкий";

    /// <summary>Описание базы.</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>Теги базы данных.</summary>
    private List<string> _tags = new();

    public List<string> Tags
    {
        get => _tags;
        set
        {
            _tags = value ?? new List<string>();
            OnPropertyChanged();
        }
    }

    /// <summary>
    /// Сообщает UI об изменении набора тегов.
    /// Подменяет список новым экземпляром — иначе ItemsControl не обновляется.
    /// </summary>
    public void NotifyTagsChanged()
    {
        _tags = new List<string>(_tags);
        OnPropertyChanged(nameof(Tags));
    }

    /// <summary>Дерево метаданных конфигурации.</summary>
    public MetadataNode? MetadataRoot { get; set; }

    /// <summary>
    /// Возвращает строку соединения для отображения.
    /// </summary>
    public string ConnectionStringDisplay => Connection.ToConnectionString();

    /// <summary>
    /// Название группы для отображения. Базы без группы отображаются в группе «Без группы».
    /// </summary>
    public string GroupDisplay => string.IsNullOrWhiteSpace(Group) ? "Без группы" : Group;

    /// <summary>
    /// Группа, в которой отображается база в общем списке. Закреплённые базы
    /// выводятся в отдельной группе «Закреплённые» вверху таблицы, независимо от их группы.
    /// </summary>
    public string DisplayGroup => IsPinned ? "Закреплённые" : GroupDisplay;

    /// <summary>
    /// Порядок группы для сортировки: закреплённые базы всегда идут первыми.
    /// </summary>
    public int GroupSortOrder => IsPinned ? 0 : 1;

    /// <summary>
    /// Возвращает путь к файловой базе в кавычках (без префикса File=).
    /// Для клиент-серверного режима возвращает строку соединения.
    /// </summary>
    public string ConnectionPathDisplay => Connection.Type switch
    {
        ConnectionType.File => $"\"{Connection.FilePath}\"",
        _ => Connection.ToConnectionString()
    };

    /// <summary>
    /// Тип подключения для отображения (файловая или клиент-серверная).
    /// </summary>
    public string ConnectionTypeDisplay => Connection.Type switch
    {
        ConnectionType.File => "Файловая",
        ConnectionType.WebServer => "Веб-сервер",
        _ => "Клиент-серверная"
    };

    /// <summary>
    /// Режим запуска для отображения. Используется в колонке «Режим запуска».
    /// </summary>
    public string ParsedLaunchMode => string.IsNullOrWhiteSpace(LaunchMode)
        ? "Автоматический"
        : LaunchMode;

    /// <summary>
    /// Сервер или база для отображения. Для файлового режима — путь к базе,
    /// для клиент-серверного — сервер и имя базы. Используется в колонке «Сервер/База».
    /// </summary>
    public string ServerDatabaseDisplay => Connection.Type switch
    {
        ConnectionType.File => string.IsNullOrWhiteSpace(Connection.FilePath)
            ? "—"
            : Connection.FilePath,
        _ => string.IsNullOrWhiteSpace(Connection.Server)
            ? Connection.DatabaseName
            : $"{Connection.Server}\\{Connection.DatabaseName}"
    };

    /// <summary>
    /// Дата последнего запуска для отображения.
    /// </summary>
    public string LastLaunchDisplay =>
        LastLaunchDate.HasValue
            ? LastLaunchDate.Value.ToString("dd.MM.yyyy HH:mm")
            : "Не запускалась";

    /// <summary>История запусков (до 30 последних записей).</summary>
    private List<LaunchHistoryEntry> _launchHistory = new();

    public List<LaunchHistoryEntry> LaunchHistory
    {
        get => _launchHistory;
        set
        {
            _launchHistory = value ?? new List<LaunchHistoryEntry>();
            OnPropertyChanged();
            OnPropertyChanged(nameof(LaunchHistoryDisplay));
        }
    }

    /// <summary>Краткий текст для UI: число записей / последний.</summary>
    public string LaunchHistoryDisplay =>
        _launchHistory.Count == 0
            ? "Нет записей"
            : $"{_launchHistory.Count} зап., посл.: {_launchHistory[0].Timestamp:dd.MM HH:mm}";

    /// <summary>Добавить запись в историю (новые сверху, максимум 30).</summary>
    public void AddLaunchHistory(string mode, string details = "")
    {
        _launchHistory.Insert(0, new LaunchHistoryEntry
        {
            Timestamp = DateTime.Now,
            Mode = mode,
            Details = details ?? ""
        });
        while (_launchHistory.Count > 30)
            _launchHistory.RemoveAt(_launchHistory.Count - 1);
        LastLaunchDate = DateTime.Now;
        OnPropertyChanged(nameof(LaunchHistory));
        OnPropertyChanged(nameof(LaunchHistoryDisplay));
        OnPropertyChanged(nameof(LastLaunchDisplay));
    }

    private long? _fileSizeBytes;
    private bool _fileSizeResolved;

    /// <summary>Размер файловой ИБ в байтах (null — не файловая / не посчитан).</summary>
    public long? FileSizeBytes
    {
        get => _fileSizeBytes;
        set
        {
            if (SetProperty(ref _fileSizeBytes, value))
            {
                _fileSizeResolved = true;
                OnPropertyChanged(nameof(FileSizeDisplay));
            }
        }
    }

    /// <summary>Размер для колонки списка.</summary>
    public string FileSizeDisplay
    {
        get
        {
            if (Connection.Type != ConnectionType.File)
                return "—";
            if (!_fileSizeResolved || !_fileSizeBytes.HasValue)
                return "…";
            return FormatSize(_fileSizeBytes.Value);
        }
    }

    public static string FormatSize(long bytes)
    {
        if (bytes < 1024) return $"{bytes} Б";
        double kb = bytes / 1024.0;
        if (kb < 1024) return $"{kb:0.#} КБ";
        double mb = kb / 1024.0;
        if (mb < 1024) return $"{mb:0.#} МБ";
        double gb = mb / 1024.0;
        return $"{gb:0.##} ГБ";
    }

    /// <summary>
    /// Инициалы базы для отображения в аватаре списка.
    /// </summary>
    public string Initials
    {
        get
        {
            if (string.IsNullOrWhiteSpace(Name))
                return "1С";

            var parts = Name.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0)
                return "1С";

            if (parts.Length == 1)
                return parts[0].Substring(0, Math.Min(2, parts[0].Length)).ToUpperInvariant();

            return (parts[0][0].ToString() + parts[1][0].ToString()).ToUpperInvariant();
        }
    }
}